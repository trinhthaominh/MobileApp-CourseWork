package com.example.bai1_customspinner

class Car(val img: Int, val name: String)  {
}